package com.example.bhrdjawabarat;

public class PrayerTimes {
    private String fajrTime;
    private String dhuhrTime;
    private String asrTime;
    private String maghribTime;
    private String ishaTime;

    public PrayerTimes(String fajrTime, String dhuhrTime, String asrTime, String maghribTime, String ishaTime) {
        this.fajrTime = fajrTime;
        this.dhuhrTime = dhuhrTime;
        this.asrTime = asrTime;
        this.maghribTime = maghribTime;
        this.ishaTime = ishaTime;
    }

    public String getFajrTime() {
        return fajrTime;
    }

    public String getDhuhrTime() {
        return dhuhrTime;
    }

    public String getAsrTime() {
        return asrTime;
    }

    public String getMaghribTime() {
        return maghribTime;
    }

    public String getIshaTime() {
        return ishaTime;
    }
}
