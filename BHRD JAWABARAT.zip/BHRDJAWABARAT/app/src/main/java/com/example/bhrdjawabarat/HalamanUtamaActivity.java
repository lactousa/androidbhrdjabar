package com.example.bhrdjawabarat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.osmdroid.util.GeoPoint;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HalamanUtamaActivity extends AppCompatActivity {

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;

    private LocationManager locationManager;
    private LocationListener locationListener;

    private TextView textViewLocation;

    private TextView cityNameTextView;

    private RecyclerView recyclerView;
    private BeritaAdapter beritaAdapter;
    private ArrayList<BeritaModel> beritaModel;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_halaman_utama);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        cityNameTextView = findViewById(R.id.cityNameTextView);

        TextView textViewDate = findViewById(R.id.textViewDate);
        beritaAdapter = new BeritaAdapter(beritaModel);

        getData();

        recyclerView = findViewById(R.id.recyclerView);
        beritaAdapter = new BeritaAdapter(beritaModel);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(HalamanUtamaActivity.this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(beritaAdapter);

        cityNameTextView = findViewById(R.id.cityNameTextView);

        // Inisialisasi locationManager dan locationListener
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        locationListener = new LocationListener() {

            private void updateLocationText(double latitude, double longitude) {
                TextView textViewLatitude = findViewById(R.id.textViewLatitude);
                TextView textViewLongitude = findViewById(R.id.textViewLongitude);

                textViewLatitude.setText("Latitude: " + latitude);
                textViewLongitude.setText("Longitude: " + longitude);
            }
            @Override
            public void onLocationChanged(Location location) {
                double latitude = location.getLatitude();
                double longitude = location.getLongitude();
                updateLocationText(latitude, longitude);

                // Simpan nilai latitude dan longitude ke SharedPreferences
                SharedPreferences sharedPreferences = getSharedPreferences("user_location", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("latitude", String.valueOf(latitude));
                editor.putString("longitude", String.valueOf(longitude));
                editor.apply();

            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {}

            @Override
            public void onProviderEnabled(String provider) {}

            @Override
            public void onProviderDisabled(String provider) {}



        };



        // Meminta izin lokasi jika belum diberikan
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST_CODE);
        } else {
            enableLocation();
        }


        // Menampilkan tanggal saat ini
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy", Locale.getDefault());
        Date currentDate = new Date();
        String formattedDate = dateFormat.format(currentDate);
        textViewDate.setText(formattedDate);

        ImageView imageViewKiblat = findViewById(R.id.imageView9);
        imageViewKiblat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HalamanUtamaActivity.this, KiblatActivity.class);
                startActivity(intent);
            }
        });
    }

    private void getData() {
        beritaModel = new ArrayList<>();
        beritaModel.add(new BeritaModel("BHRD Jabar dan Kemenag Kab. Sumedang menggelar Seminar dan Pelatihan “Implementasi Ilmu Falak dalam Konsep Mengenal Waktu” se kabupaten Sumedang", R.drawable.berita5, "Sumedang, 4 September 2023 – Kantor Kementerian Agama (Kemenag) Sumedang, Jawa Barat, menjadi tuan rumah untuk sebuah seminar yang mengangkat topik menarik, “Implementasi Ilmu Falak dalam Konsep Mengenal Waktu.” Acara ini berlangsung pada tanggal 4 September 2023, dan dihadiri oleh lebih dari 200 peserta dari berbagai kalangan.\n" +
                "\n" +
                "Seminar ini menghadirkan narasumber yang berpengalaman dalam bidang Ilmu Falak, termasuk perwakilan dari Badan Hisab Rukyat Dan Kepastian Waktu (BHRD) Provinsi Jawa Barat, serta perwakilan dari Kantor Wilayah Kementerian Agama (Kanwil Kemenag) Jabar. Selain itu, ada juga praktisi yang telah lama berkecimpung dalam Ilmu Falak. \n" +
                "\n" +
                "Perwakilan BHRD Jawa Barat Encep Abdul Rojak mengatakan bahwa kegiatan ini bertujuan untuk memberikan edukasi mengenai ilmu falak kepada Masyarakat luas. Karena ilmu falak ini sangat penting berkaitan dengan mengenal waktu akurasi waktu solat dan arah kiblat yang tepat dan sebagainya.\n" +
                "“Ilmu ini jarang sekali dipahami, oleh sebab itu kami mengadakan edukasi dengan melibatkan kementerian agama bersinergi dengan  pemerintah Provinsi Jawa Barat, dan kanwil kementerian agama jabar” ucapnya.\n" +
                "Salah satu tujuan utama dari seminar ini adalah untuk meningkatkan pemahaman masyarakat tentang implementasi Ilmu Falak dalam menentukan waktu-waktu penting dalam agama Islam, seperti waktu salat, awal dan akhir Ramadan, dan hari-hari penting lainnya dalam kalender Islam.\n" +
                "Dalam pembukaan seminar, Kepala Kemenag Jajang Apipudin menyatakan, “Para peserta merupakan perwakilan dari guru PAI MTs dan MA, perwakilan ormas Islam, penyuluh Agama Islam, kalangan perguruan tinggi, dan yang lainnya. Ilmu Falak adalah bagian penting dalam pemahaman agama Islam, dan pengetahuan tentang pergerakan benda langit sangat penting untuk menentukan waktu-waktu ibadah. Melalui seminar ini, kami berharap para peserta dapat memahami dan mengaplikasikan Ilmu Falak dalam kehidupan sehari-hari.”\n" +
                "Narasumber dalam seminar ini memberikan presentasi yang informatif tentang prinsip-prinsip dasar Ilmu Falak, peralatan yang digunakan, serta bagaimana menghitung waktu-waktu penting dalam Islam. Mereka juga menjawab pertanyaan peserta dan memberikan contoh konkret tentang bagaimana Ilmu Falak dapat diaplikasikan dalam praktik keagamaan.\n" +
                "Seminar ini mendapatkan sambutan hangat dari peserta, yang datang dari berbagai wilayah di Jawa Barat. Mereka mengapresiasi upaya Kantor Kemenag Sumedang dalam mengadakan acara ini dan berharap ada lebih banyak seminar serupa di masa depan.\n" +
                "Kegiatan seminar ini sejalan dengan upaya pemerintah dan lembaga agama untuk meningkatkan pemahaman masyarakat tentang aspek-aspek keagamaan. Semoga pemahaman tentang Ilmu Falak dapat terus berkembang dan memperkaya praktik-praktik keagamaan masyarakat. (C.01)\n"));
        beritaModel.add(new BeritaModel("Unisba Kerja Sama dengan BHRD dan Kemenag Jabar Lakukan Ru’yatul Hilal", R.drawable.thumbnail_berita1, "KOMHUMAS-Dalam rangka menyambut Idul Adha 10 Dzulhijjah 1443 H, Fakultas Syariah (Fasya) Unisba bekerja sama dengan BHRD (Badan Hisab dan Rukyat Daerah) dan Kementrian Agama (Kemenag) Provinsi Jawa Barat melakukan Ru’yatul Hilal dalam penentuan 1 Dzulhijjah 1443 H.\n" +
                "\n" +
                "Pengamatan ini dilaksanakan di Observatorium Albiruni Fasya Unisba yang terletak di Rooftop Gedung Fakultas Kedokteran Unisba, Rabu (29/06/2022).\n" +
                "\n" +
                "Pada kesempatan ini, beberapa pihak turut terlibat dalam pengamatan hilal yaitu Civitas Akademika Unisba, perwakilan Kemenag, BHRD Prov. Jawa Barat, BHR Kota Bandung, BHR Kota Cimahi, Ormas Islam, Siswa, Santri, dan lainnya.\n" +
                "\n" +
                "Ketua Tim BHRD Jabar, Prof. Dr. H. Encup Supriatna, M.Si.  mengatakan, hasil dari pengamatan ini menunjukkan bahwa hilal tidak tampak terlihat.\n" +
                "\n" +
                "Menurutnya, faktor yang mempengaruhi adalah kondisi cuaca berawan dan gelap, serta posisi berada di bawah 2 derajat sehingga hilal sulit terlihat dengan baik.\n" +
                "\n" +
                "Ia menuturkan, pengamatan hilal bukan satu-satunya metode untuk menentukan awal bulan Hijriah, akan tetapi ada juga  yang sudah menetapkan 1 Dzulhijjah 1443 H dengan metode lain.\n" +
                "\n" +
                "Sementara itu, ketua pelaksana ru’yat hilal awal Dzulhijjah 1443 H, Encep Abdul Rojak, S.H.I., M.Sy., mengatakan, kegiatan ini berstatus resmi terdaftar sebagai titik pengamatan hilal.  Hasil pengamatannya akan dilaporkan kepada Kepada Kemenag Republik Indonesia sebagai bahan untuk Itsbat Awal Dzulhijjah 1443 H. “Keputusan awal bulan Dzulhijjah 1443 H akan menunggu pengumuman resmi dari Pemerintah c.q Kemenag,” katanya.\n" +
                "\n" +
                "Dosen Hukum Keluarga Islam ini menuturkan, ijtimak atau konjungsi terjadi pada Rabu, 29 Juni 2022, Pkl. 08.20 WIB. “Konjungsi berarti posisi Bumi, Bulan, dan Matahari berada pada satu garis astronomis. Sejak terjadinya konjungsi sampai dengan waktu pengamatan disebut Umur bulan/hilal sekitar 9 jam 29 menit,” jelasnya.\n" +
                "\n" +
                "Pengamatan hilal ini kata Encep, akan dimulai saat matahari terbenam yaitu pkl. 17.45 WIB. Lama pengamatan hilal dilakukan selama 10 menit, karena bulan akan terbenam pada pkl. 17.55 WIB.\n" +
                "\n" +
                "“Posisi bulan/hilal berada pada Azimuth 297˚17’02”. Sedangkan posisi Matahari berada pada azimuth 293˚10’03”. Nilai ini dihitung dari titik Utara sejati ke arah Timur-Selatan-Barat melalui lingkaran horizon atau ufuk sampai dengan proyeksi bulan dan matahari di ufuk searah dengan perputaran jarum jam. Berdasarkan data ini, bulan atau hilal berada di sebelah Utara/Kanan Matahari dengan selisih +4˚06’59”,” terangnya.\n" +
                "\n" +
                "Encep mengatakan, pada awal pengamatan hilal, tinggi hilal +1˚52’42”, selanjutnya secara berurutan Pkl. 17.50 WIB (+0˚51’44”). Tinggi hilal ini dihitung dari ufuk secara vertikal sampai dengan posisi bulannya. Jarak sudut lengkung bulan dari matahari yang disebut Elongasi berada pada nilai +4˚46’34”.\n" +
                "\n" +
                "Lebih lanjut Encep menjelaskan, pengamatan ini menggunakan Teropong Digital Computerize tiga buah & Teropong manual dua buah, serta dilakukan secara manual dan digital. \n" +
                "\n" +
                "“Pengamatan digital menggunakan teropong Cem60 merk iOptron yang terpasang di dalam doom. Dibantu juga dengan kamera CCD BW yang menghubungkan teropong dengan laptop. Untuk membuka kamera tersebut digunakan software Sharpcap yang berfungsi untuk memonitor tangkapan hilal/matahari pada teropong. Melalui software ini pun digunakan untuk mendokumentasikan hilal dalam bentuk foto atau video. Apabila hasilnya tidak diketahui secara jelas objeknya / hilalnya, maka akan dilakukan olah citra hilal dengan software lainnya seperti iris atau siril. Keduanya merupakan software astronomi yang berfungsi untuk mengolah citra hilal agar terlihat kontras. Semuanya ini dilakukan oleh tim Observatorium Albiruni Fasya Unisba,” jelasnya.\n" +
                "\n" +
                "Teropong utama dalam pengamatan hilal lanjut Encep, akan disambungkan melalui media TV untuk menampilkan tangkapan teropong sehingga setiap orang yang hadir memiliki kesempatan yang sama untuk melihat hilal.***"));
        beritaModel.add(new BeritaModel("BHRD Ciamis Jadikan POB Gunung Putri Lokasi Rukyatul Hilal", R.drawable.thumbnail_berita2, "Gunung Putri (Humas Kab. Ciamis)\n" +
                "\n" +
                "Pusat Observasi Bulan (POB) Gunung Putri Lapas Banjar menjadi tempat pengamatan Tim Badan Hisab dan Rukyat Daerah (BHRD) Kabupaten Ciamis dalam melakukan pengamatan rukyatul hilal untuk menentukan awal Ramadhan 1444H.\n" +
                "\n" +
                "Kepala Kemenag Ciamis, H. Usep Saepudin Muhtar mengatakan tujuan dilaksanakannya rukyatul hilal untuk menentukan awal bulan suci Ramadan.\n" +
                "\n" +
                "“Rukyat untuk melihat apakah besok masuk 1 Ramadhan 1444H. Untuk  kepastian awal Ramadhan menunggu hasil isbat yang akan disampaikan langsung oleh Menteri Agama, yang dapat kita saksikan secara live di televisi,” ungkapnya pada Rabu (22-3-2023).\n" +
                "\n" +
                "Terselenggaranya Rukyat Hilal di POB Lapas Banjar mendapat apresiasi dari Kabid Penais Zawa Kanwil Kemenag Propinsi Jawa Barat, H. Ohan Burhan.\n" +
                "\n" +
                "“Atas nama Kanwil mengapresiasi pelaksanaan di tempat ini, mudah mudahan kedepannya bisa dilaksanakan tiap bulan untuk penetapan awal bulan hijriah dan hari hari besar islam,” ujarnya.\n" +
                "\n" +
                "H. Ohan mengungkapkan, metode rukyat dan hisab tidak perlu diperdebatkan, tetapi harus saling menguatkan, sebagai salah satu bentuk teloransi.\n" +
                "\n" +
                "“Dalam pelaksanaan bulan Ramadhan harus saling menghormati, walaupun ada perbedaan dalam pelaksanaannya,” ungkapnya.\n" +
                "\n" +
                "Sementara itu, Ketua BHRD Kota Banjar, H. Badar menjelaskan berdasarkan kriteria MABIMS (Menteri Agama Brunei, Indonesia, Malaysia, dan Singapura) ketinggian hilal adalah 3 derajat.\n" +
                "\n" +
                "“Hasil dari pantauan Hilal dari beberapa titik di daerah tertentu akan menjadi rujukan dalam melakukan sidang isbat penentuan tanggal 1 Ramadhan 1444 H yang dilaksanakan oleh Kementerian Agama RI, MABIMS telah menetapkan kriteria ketinggian hilal dari 2 derajat menjadi 3 derajat, ” Ujar H. Badar yang juga menjabat sebagai Kasi Bimas Islam Kemenag Kota Banjar.\n" +
                "\n" +
                "Menurut data BHRD, umur hilal pada rabu, 22 Maret 2023 adalah 17 jam 32 menit, dengan Azimuth 273”49” dan tinggi 8”11”, dengan waktu terbenam matahari pukul 17:55:51 WIB dan Azzimuth 270”31” dan waktu terbenam hilal pukul 18:31:13 WIB dan Azzimuth 272”50”. Berdasarkan hasil pengamatan Tim BHRD di POB Gunung Putri, hilal tidak terlihat karena tertutup oleh awan tebal.\n" +
                "\n" +
                "Kontributor : Arif"));
        beritaModel.add(new BeritaModel("Bupati Bandung Melantik Pengurus Badan Hisab Rukyat Daerah (BHRD) Periode 2022-2026", R.drawable.thumbnail_berita3, "BANDUNG - Bupati Bandung, Dadang Supriatna melantik sejumlah pengurus Badan Hisab Rukyat Daerah (BHRD) Kabupaten Bandung, di Gedung Mohammad Toha, komplek Pemda Kabupaten Bandung, Selasa (7/2/2023).\n" +
                "\n" +
                "Bupati Bandung Dadang Supriatna mengharapkan agar BHRD sesegera mungkin melakukan rapat koordinasi untuk menentukan anggaran dan program kerja, menginggat sudah dekatnya bulan ramadhan. Sehingga persiapan untuk menginformasikan dimulai Ramadhon bisa diantisipasi secepatnya. Dan dapat berkoordinasi dengan lembaga lainnya.\n" +
                "\n" +
                "Bupati juga menawarkan bantuan anggaran dan peralatan yang diperlukan BHRD. \"Untuk alat yang akan di gunakan, kita akan beli. Dan tolong anggaran untuk BHRD yang sudah dilantik ini, agar dianggarkan,\" pinta Bupati Dadang Supriatna kepada pejabat Bagian Kesra (Kesejahteraan rakyat) Kabupaten Bandung yang turut hadir pada kesempatan itu.\n" +
                "\n" +
                "Pada kesempatan itu Bupati Bandung menekankan juga pada BHRD agar selalu berkoordinasi dengan Pimpinan Daerah DMI (Dewan Masjid Indonesia) agar ada kesinergian dalam praktek kerjanya nanti.\n" +
                "\n" +
                "\n" +
                "Pelantikan lembaga BHRD Kabupaten Bandung turut disaksikan oleh Forkopimda, pejabat Kemenag Kabupaten Bandung, Pengadilan Agama (PA) Soreang, Pengadilan Negeri (PN) Bale Bandung, Kejaksaan Negeri (Kejari) Kabupaten Bandung, Polresta Bandung, pejabat dari Pemkab Bandung, pimpinan ormas Islam, Ketua LPTQ, Forum Camat, KUA dan PC DMI 31 Kecamatan, serta PD DMI Kab. Bandung. Usai pelantikan Ketua BHRD, Sufroyadi mendapat banyak masukan dari Kepala Kemenag Kabupaten Bandung, Abdurahim, yang memintanya untuk mulai membuat program dan bekerja secepatnya. Jika BHRD sebelum memiliki peralatan, Abdurahim mempersilakan BHRD untuk menggunakan alat milik Kemenag.\n" +
                "\n" +
                "Sementara Ketua BHRD Jawa Barat Prof Encup Supriatna berharap agar BHRD Kabupaten Bandung yang sudah dilantik agar bisa memulai langkah yang strategis, semisal memulai penentuan arah kiblat untuk setiap masjid, baik yang ada disetiap daerah, maupun arah kiblat seperti di hotel atau ditempat lainnya."));
        beritaModel.add(new BeritaModel("BHRD Kab. Bandung Laksanakan Kalibrasi Penentuan Arah Kiblat di Beberapa Masjid Yang Terdaftar Untuk di Kalibrasi Arah Kiblatnya", R.drawable.thumbnail_berita4, "Badan hisab rukyat daerah (BHRD) Kabupaten Bandung, Melaksanakan pengukuran kalibrasi arah kiblat, untuk beberapa masjid yang telah mengisi permohonan penentuan arah kiblat melalui link, di Desa Buah Batu Selasa (28/3/2023).\n" +
                "\n" +
                "Ketua BHRD Kab. Bandung Sufroyadi mengatakan, untuk permohonan pendaftaran, di isi oleh pengurus masjid DKM dan diketahui PR DMI yang direkomendasi PD DMI Kab. Bandung untuk kalibrasi arah kiblat.\n" +
                "\n" +
                "Adapun beberapa masjid yang ada di Kab. Bandung, hari ini yang di kalibrasi oleh Badan Hisab Rukyat Daerah Kabupaten Bandung (BHRD) diantaranya,\n" +
                "\n" +
                "1. Masjid Al-Wahab Desa Buahbatu Kecamatan Bojongsoang\n" +
                "2. Masjid Ulul Albab Desa Buahbatu Kecamatan Bojongsoang\n" +
                "3. Masjid GBI Desa Buahbatu Kecamatan Bojongsoang\n" +
                "4. Raudhatul Jannah Desa Buahbatu Kecamatan Bojongsoang\n" +
                "5. Masjid At-Taqwa Desa Buahbatu Kecamatan Bojongsoang\n" +
                "6. Masjid Al-Falah Desa Buahbatu Kecamatan Bojongsoang\n" +
                "\n" +
                "Kemudian “Pengukuran pertama oleh tim BHRD ini adalah Masjid al wahhab Rancaoray yang berada di Rw. 01./ Jalan Batusari samping kantor desa Buahbatu, dengan Ketua DKM Al Wahab, Rw 01 Desa Buahbatu, atas nama H. Ratim Sutisna”. Katanya melalui telepon Kamis (30/3/2023).\n" +
                "Lanjutnya, ia menuturkan, Petugas/Tim BHRD yang melakukan pengukuran kalibrasi\n" +
                "Memberikan tugas kepada\n" +
                "\n" +
                "1. Bidang : Pengamatan Benda Langit\n" +
                "Nama : H. Asep Setiawan, S.Pd.I\n" +
                "\n" +
                "2. Bidang : Pengukuran Arah Kiblat\n" +
                "Nama : Moh. Nizar Meidiana, S.Th.I\n" +
                "H. Heri Ali Imron, S.Ag\n" +
                "M. Rahmatuloh, S.Ag.\n" +
                "Farham M Ramadhan\n" +
                "Kiki Sodikin, S.H.\n" +
                "\n" +
                "3. Bidang : Peralatan dan Perlengkapan\n" +
                "Nama : Apep Pardi, S.Pd, M.M\n" +
                "Herlan Hermawan, S.Sy\n" +
                "\n" +
                "4. Bidang : Humas Infokom\n" +
                "Nama : Bambang Melga, M.Pd\n" +
                "H.Yudha Trisyah Putra, MM\n" +
                "\n" +
                "5. Pendamping :\n" +
                "\n" +
                "1. H. Muchlis Sohari, M.Sos\n" +
                "2. Andri Sani Awaludin, S.Pd\n" +
                "3. Hasbulloh, S.Pd.I\n" +
                "\n" +
                "“Selama bulan Ramadhan ini, bahwa para petugas tersebut, sudah mengagendakan untuk bisa mengkalibrasi masjid yang sudah membuat permohonan melalui link sekertariat BHRD” ujarnya\n" +
                "\n" +
                "Menurutnya Masjid yang sudah beres di Kalibrasi diantara nya\n" +
                "1 Masjid agung Al Fathu, di komplek perkantoran Pemda Soreang.\n" +
                "2. Mushola Al-Fatih Rumdin Bupati Bandung\n" +
                "3. Yayasan Masjid Al Irfan.\n" +
                "\n" +
                "Selain itu Sufroyadi, M.Pd.I, meyampaikan bahwa, “Bagian peran dari BHRD kabupaten Bandung bukan hanya itu saja teatpi tugas yang lainnya yaitu di Ramadhan ini 1444H, ialah mengatur waktu, jadwal imsakiyah kabupaten Bandung yang sudah diterbitkan dan di sosialisasikan”\n" +
                "Mengenai target ia juga menyebutkan, “kalibrasi arah Kiblat masjid mushola yang saat ini di kab. Bandung, jumlahnya sekitar 9000 lebih masjid dan Musholla semoga terselesaikan Kalibrasi arah kiblatnya”\n" +
                "\n" +
                "Ketua BHRD yang kerap disafa akrabn kang yadi itu juga menegaskan, bahwa di bulan ramadhan ini hal yang perlu menjadi peehatian adalah waktu Maghrib, dimana menurutnya waktu semangatnya untuk berbuka puasa.\n" +
                "\n" +
                "Tetapi yang menjadi kehawatirannya, Pada saat waktu maghrib itu sudah berbuka, tanpa mengetahui masuk untuk berbuka puasa karena telat beberapa menit ke waktu maghrib yang menjadi patokan.\n" +
                "\n" +
                "“kedua Arah Kiblat Kang Yadi menyampaikan arah kiblat penentu ke afdholan sholat berjamaah maupun sendiri, jika sholat di masjid, nyaman gak berfikir kiblat benarnya arahnya karena sudah di urus kalibrasi arah kiblatnya oleh pengurus, itu kan bagian tanggung jawab pengurus DKM, jamaah tinggal datang sholat berjamaah mengikuti Imam”\n" +
                "\n" +
                "“Jika sendiri sholatnya di rumah atau di tempat yg belum ada tanda arah kiblat bagaimana?.. Untuk menentukan arah kiblat, nah ini yang banyak yang ditanyakan, ibadah itu perlu ilmu jika gak tau ya bertanya ke pada ahlinya masing-masing, tentunya begitu sikap kita sebagai mujahid yang terus menerus belajar dari waktu ke waktu yang ingin memperbaiki ibadah lebih baik lebih bernilai”. Ungkapnya Pada kesempatan itu juga, Kepala Desa Buahbatu Asep Sobari, yang mengikuti pelaksanaan pengukuran kalibrasi arah kiblat di Masjid Al Wahab menyampaikan, Rasa syukur dan terima kasihnya kepada tim BHRD yang telah datang untuk mengakurasi arah Kiblat Masjid di wilayah RW setempat.\n" +
                "\n" +
                "Asep berharap semoga masjid lainnya pun bisa ikut melakukan hal yang sama untuk terciptanya rasa damai, nyaman dan aman, karena arah kiblatnya sudah pasti akurat menghadap ke Mekkah, Baitullah. Tuturnya.\n" +
                "\n" +
                "Selain itu Ketua DKM masjid merasa sangat senang dan bangga karena menyadari peran utama sebagai pengurus DKM untuk memastikan bahwa masjidnya sudah benar menghadapi kiblat. Katanya ****"));
        beritaModel.add(new BeritaModel("Hilal Terlihat di Pantai Baro Gebang Cirebon Pukul 18.02 WIB", R.drawable.thumbnail_berita5, "Pada kesempatan itu juga, Kepala Desa Buahbatu Asep Sobari, yang mengikuti pelaksanaan pengukuran kalibrasi arah kiblat di Masjid Al Wahab menyampaikan, Rasa syukur dan terima kasihnya kepada tim BHRD yang telah datang untuk mengakurasi arah Kiblat Masjid di wilayah RW setempat.\n" +
                "\n" +
                "Asep berharap semoga masjid lainnya pun bisa ikut melakukan hal yang sama untuk terciptanya rasa damai, nyaman dan aman, karena arah kiblatnya sudah pasti akurat menghadap ke Mekkah, Baitullah. Tuturnya.\n" +
                "\n" +
                "Selain itu Ketua DKM masjid merasa sangat senang dan bangga karena menyadari peran utama sebagai pengurus DKM untuk memastikan bahwa masjidnya sudah benar menghadapi kiblat. Katanya ****"));
        beritaModel.add(new BeritaModel("BHRD Jawa Barat adakan Pelatihan Fiqh Astronomi dan Ilmu Falak di Kabupaten Subang", R.drawable.thumbnail_berita6, "Ilmu falak atau lebih dikenal dengan istilah ilmu hisab adalah ilmu yang mempelajari lintasan benda-benda langit sepeeti matahari, bulan, dan bumi untuk mengetahui posisi dan kedudukan benda langit yang satu dengan benda langit lainnya.Dalam rangka memberikan wawasan mengenai ilmu falak, Badan Husab Rukyat Daerah (BHRD) Kota Tasikmalaya bersama dengan Kementerian Agama Kota Tasikmalaya gelar Pelatihan dasar ilmu falak atau astronomi, kamis (08/11) bertempat di Pondok Pesantren Assulaha.\n" +
                "\n" +
                "Pelatihan ini diselenggarakan oleh Kantor kementerian Agama kota Tasikmalaya bekerjasama dengan Badan Hisab Rukyat Daerah (BHRD) Kota Tasikmalaya. Diikuti oleh sekitar 25 orang santri dari pondok pesantren Daar el anba dan 25 orang sntri Pondok Pesantren Assulaha. Cecep Nurkholis, Penyelenggara Syariah menuturkan tujuan diadakan pelatihan ini adalah para peserta dapat memahami ilmu falak serta dapat menentukan arah kiblat .\n" +
                "\n" +
                "Ia juga menambahkan Pemerintah melalui BHRD dan Kantor Kementerian Agama sudah saatnya berkepentingan memperkenalkan tentang ilmu Falak dari ilmu dasar dasarnya  kepada masyarakat umum,  harapannya  agara di Kota Tasikmalaya ini banyak  bermunculan para  ahli ilmu falak , sehingga keberadaan ilmu falak ini tidak punah dan bisa berkembang. Ilmu falk ini dianggap sebagai ilmu yang cukup rumit karena itu perlu adanya penambahan wawasan mengenai keilmu falakan.\n" +
                "\n" +
                "“Oleh karena itu dengan adanya pelatihan ini diharapkan para peserta tertarik dan  dapat memahami  serta bermanfaat dan bisa dikembangkan di masyarakat”, imbuhnya.\n" +
                "\n" +
                "Cecep juga menjelaskan ada fenomena di masyarakat dimana ada ketidak fahaman mengenai arah kiblat, hal ini terjadi karena beberapa hal misalnya karena kurangnya pemahaman tentang praktek ilmu falak terutama penentuan arah kiblat serta kurangnya pemahaman penggunaan kompas atau atal – alat lain untuk menentukan arah kiblat.\n" +
                "\n" +
                "“selain itu terkadang penggunaan alat pengukuran seperti kompas tidak diprhatikan akurasinya”, jelasnya.\n" +
                "\n" +
                "KOntributor : Yeni Rohayati"));
    }

    private void enableLocation() {
        if (locationManager != null) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                    ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
        }
    }

    private void updateLocation(Location location) {
        double latitude = location.getLatitude();
        double longitude = location.getLongitude();
        GeoPoint geoPoint = new GeoPoint(latitude, longitude);

        String address = getAddressFromGeoPoint(geoPoint);
        if (address != null) {
            textViewLocation.setText(address);
        } else {
            textViewLocation.setText("Alamat tidak ditemukan");
        }
    }

    private String getAddressFromGeoPoint(GeoPoint geoPoint) {
        if (geoPoint != null) {
            try {
                Geocoder geocoder = new Geocoder(this, Locale.getDefault());
                List<Address> addresses = geocoder.getFromLocation(
                        geoPoint.getLatitude(), geoPoint.getLongitude(), 1
                );
                if (!addresses.isEmpty()) {
                    Address address = addresses.get(0);
                    String city = address.getLocality();
                    String district = address.getSubAdminArea();
                    String locationName = (city != null) ? city : district;
                    return locationName;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                enableLocation();
            } else {
                Toast.makeText(this, "Izin lokasi ditolak.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (locationManager != null && locationListener != null) {
            locationManager.removeUpdates(locationListener);
        }
    }

    public void goToTentangBHRD(View view) {
        Intent intent = new Intent(this, TentangBhrdActivity.class);
        startActivity(intent);
    }

    public void goToCalenderHijriyah(View view) {
        Intent intent = new Intent(this, CalenderHijriyahActivity.class);
        startActivity(intent);
    }

    public void goToKompasKiblat(View view) {
        Intent intent = new Intent(this, KompasKiblatActivity.class);
        startActivity(intent);
    }

    public void goToJadwalSholat(View v) {
        try {
            // Pindah ke JadwalSholatActivity
            Intent intent = new Intent(HalamanUtamaActivity.this, JadwalSholatActivity.class);
            startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
            // Tambahkan penanganan kesalahan di sini, seperti menampilkan pesan kesalahan kepada pengguna.
        }
    }

    public void goToInfoHilalActivity(View view) {
        Intent intent = new Intent(this, InfoHilalActivity.class);
        startActivity(intent);
    }

    public void goToRealTimeDataActivity(View view) {
        Intent intent = new Intent(this, RealTimeDataActivity.class);
        startActivity(intent);
    }

    private void convertCoordinatesToCityName(double latitude, double longitude) {
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());

        try {
            List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);

            if (addresses.size() > 0) {
                Address address = addresses.get(0);
                String cityName = address.getLocality();
                cityNameTextView.setText("Kota: " + cityName);
            } else {
                cityNameTextView.setText("Tidak dapat menemukan nama kota.");
            }
        } catch (IOException e) {
            e.printStackTrace();
            cityNameTextView.setText("Gagal mengonversi koordinat ke nama kota. Pastikan perangkat terhubung ke internet dan koordinat valid.");
        }
    }




}
