package com.example.bhrdjawabarat;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class PrayerTimesAPIManager {

    private static final String TAG = PrayerTimesAPIManager.class.getSimpleName();
    private static final String API_BASE_URL = "http://api.aladhan.com/v1/timingsByCity";

    public interface PrayerTimesListener {
        void onPrayerTimesFetched(PrayerTimes prayerTimes);
    }

    public static void fetchPrayerTimes(String city, String country, final PrayerTimesListener listener) {
        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    // Build the URL for the API request
                    URL url = new URL(API_BASE_URL + "?city=" + city + "&country=" + country + "&method=2");

                    // Create connection
                    HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                    urlConnection.setRequestMethod("GET");

                    // Get the response content
                    InputStream in = urlConnection.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                    StringBuilder response = new StringBuilder();
                    String line;

                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }

                    // Parse the JSON response
                    JSONObject jsonResponse = new JSONObject(response.toString());
                    JSONObject data = jsonResponse.getJSONObject("data");
                    JSONObject timings = data.getJSONObject("timings");

                    PrayerTimes prayerTimes = new PrayerTimes(
                            timings.getString("Fajr"),
                            timings.getString("Dhuhr"),
                            timings.getString("Asr"),
                            timings.getString("Maghrib"),
                            timings.getString("Isha")
                    );

                    // Notify the listener with the fetched prayer times
                    listener.onPrayerTimesFetched(prayerTimes);

                } catch (IOException | JSONException e) {
                    Log.e(TAG, "Error fetching prayer times: " + e.getMessage());
                }
            }
        });
    }
}
